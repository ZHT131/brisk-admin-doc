const n={};n.render=function(n,e){return null};export{n as default};
